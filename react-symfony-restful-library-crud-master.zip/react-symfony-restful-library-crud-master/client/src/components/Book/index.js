import List from './List';
import Edit from './Edit';

export default {List, Edit};