import React from "react"

function Library(props) {

  return (
      <h1>ALOO</h1>
  );
}

export default Library;